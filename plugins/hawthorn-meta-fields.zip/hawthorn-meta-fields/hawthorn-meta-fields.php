<?php
/*
Plugin Name: Hawthorn Meta Fields
Plugin URI: http://solopine.com
Description: Adds additional meta fields for your posts and adds index shortcode
Author: Solo Pine
Version: 1.0
Text domain: hawthorn-meta-fields
Author URI: http://solopine.com
*/

function hawthorn_meta_fields_init() {

	define( 'HAWTHORN_META_FIELDS_BASE', plugin_basename( __FILE__ ) );
	
	// load language files
	load_plugin_textdomain( 'hawthorn-meta-fields', false, dirname( HAWTHORN_META_FIELDS_BASE ) . '/lang/' );
}
add_action( 'init', 'hawthorn_meta_fields_init' );

/**
 * Adds a meta box to the post editing screen
 */
function hawthorn_custom_meta() {
    add_meta_box( 'hawthorn_meta', __( 'Post Options', 'hawthorn-meta-fields' ), 'hawthorn_meta_callback', 'post' );
	add_meta_box( 'hawthorn_meta', __( 'Page Options', 'hawthorn-meta-fields' ), 'hawthorn_meta_callback', 'page' );
}
add_action( 'add_meta_boxes', 'hawthorn_custom_meta' );

/**
 * Outputs the content of the meta box
 */
function hawthorn_meta_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'hawthorn_nonce' );
    $hawthorn_stored_meta = get_post_meta( $post->ID );
	global $typenow;
    ?>
	
	<?php if($typenow == 'page') : ?>
	<div id="sp-blog-options">
		<h5>Blog Template Options</h5>
		
		<p>
			<label for="meta-text-blog-heading" class="prfx-row-title"><?php _e( 'Blog Heading', 'hawthorn-meta-fields' )?></label>
			<input type="text" name="meta-text-blog-heading" id="meta-text-blog-heading" value="<?php if ( isset ( $hawthorn_stored_meta['meta-text-blog-heading'] ) ) echo $hawthorn_stored_meta['meta-text-blog-heading'][0]; ?>" />
		</p>
		
		<p>
			<label for="meta-select-blog-layout" class="prfx-row-title"><?php _e( 'Blog Layout', 'hawthorn-meta-fields' )?></label>
			<select name="meta-select-blog-layout" id="meta-select-blog-layout">
				<option value="full_post" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'full_post' ); ?>><?php _e( 'Full Post Layout', 'hawthorn-meta-fields' )?></option>';
				<option value="grid" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'grid' ); ?>><?php _e( 'Grid Layout', 'hawthorn-meta-fields' )?></option>';
				<option value="full_grid" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'full_grid' ); ?>><?php _e( '1 Full then Grid', 'hawthorn-meta-fields' )?></option>';
				<option value="list" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'list' ); ?>><?php _e( 'List Layout', 'hawthorn-meta-fields' )?></option>';
				<option value="full_list" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'full_list' ); ?>><?php _e( '1 Full then List', 'hawthorn-meta-fields' )?></option>';
				<option value="list_alt" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'list_alt' ); ?>><?php _e( 'Alternating List Layout', 'hawthorn-meta-fields' )?></option>';
				<option value="full_list_alt" <?php if ( isset ( $hawthorn_stored_meta['meta-select-blog-layout'] ) ) selected( $hawthorn_stored_meta['meta-select-blog-layout'][0], 'full_list_alt' ); ?>><?php _e( '1 Full then Alternating List Layout', 'hawthorn-meta-fields' )?></option>';
			</select>
		</p>
		
		<p>
			<label for="meta-number-posts" class="prfx-row-title"><?php _e( '# of Posts Per Page', 'hawthorn-meta-fields' )?></label>
			<input type="number" min="1" max="100" step="1" name="meta-number-posts" id="meta-number-posts" value="<?php if ( isset ( $hawthorn_stored_meta['meta-number-posts'] ) ) : echo $hawthorn_stored_meta['meta-number-posts'][0]; else : echo 9; endif; ?>" />
		</p>
		
		<p>
			<label for="meta-blog-category" class="prfx-row-title"><?php _e( 'Filter by Category (slug)', 'hawthorn-meta-fields' )?></label>
			<input type="text" name="meta-blog-category" id="meta-blog-category" value="<?php if ( isset ( $hawthorn_stored_meta['meta-blog-category'] ) ) echo $hawthorn_stored_meta['meta-blog-category'][0]; ?>" />
			<small style="display:block;">Separate category slugs with a comma. Leave this field blank to show all categories.</small>
		</p>
		
		<p>
			<span class="prfx-row-title"><?php _e( 'Fullwidth Layout (no sidebar)', 'hawthorn-meta-fields' )?>:</span>
			<div class="prfx-row-content">
				<label for="meta-checkbox-fullwidth">
					<input type="checkbox" name="meta-checkbox-fullwidth" id="meta-checkbox-fullwidth" value="yes" <?php if ( isset ( $hawthorn_stored_meta['meta-checkbox-fullwidth'] ) ) checked( $hawthorn_stored_meta['meta-checkbox-fullwidth'][0], 'yes' ); ?> />
				</label>
			</div>
		</p>
		
		<p>
			<span class="prfx-row-title"><?php _e( 'Include Page Content', 'hawthorn-meta-fields' )?>:</span>
			<div class="prfx-row-content">
				<label for="meta-checkbox-page-content">
					<input type="checkbox" name="meta-checkbox-page-content" id="meta-checkbox-page-content" value="yes" <?php if ( isset ( $hawthorn_stored_meta['meta-checkbox-page-content'] ) ) checked( $hawthorn_stored_meta['meta-checkbox-page-content'][0], 'yes' ); ?> />
				</label>
			</div>
		</p>	
		
		<p>
			<span class="prfx-row-title"><?php _e( 'Include Featured Slider', 'hawthorn-meta-fields' )?>:</span>
			<div class="prfx-row-content">
				<label for="meta-checkbox-blog-slider">
					<input type="checkbox" name="meta-checkbox-blog-slider" id="meta-checkbox-blog-slider" value="yes" <?php if ( isset ( $hawthorn_stored_meta['meta-checkbox-blog-slider'] ) ) checked( $hawthorn_stored_meta['meta-checkbox-blog-slider'][0], 'yes' ); ?> />
				</label>
			</div>
		</p>	
		
	</div>
	
	<?php endif; ?>
	
	<p>
		<label for="meta-image" class="prfx-row-title"><?php _e( 'Custom Featured Area Image:', 'hawthorn-meta-fields' )?></label>
		<input type="text" name="meta-image" id="meta-image" value="<?php if ( isset ( $hawthorn_stored_meta['meta-image'] ) ) echo $hawthorn_stored_meta['meta-image'][0]; ?>" />
		<input type="button" id="meta-image-button" class="button" value="<?php _e( 'Choose or Upload an Image', 'hawthorn-meta-fields' )?>" />
		<span class="solopine-description">If you're planning to display this post/page in the featured area, you can set a custom image here.<br> If you leave this field blank, the featured area will pick the featured image assigned to the post/page.</span>
	</p>
	
	<p>
		<label for="meta-textarea" class="prfx-row-title"><?php _e( 'Custom Featured Area Title:', 'hawthorn-meta-fields' )?></label>
		<textarea name="meta-textarea" id="meta-textarea"><?php if ( isset ( $hawthorn_stored_meta['meta-textarea'] ) ) echo $hawthorn_stored_meta['meta-textarea'][0]; ?></textarea>
		<span class="solopine-description">Enter a custom title for your featured post to be used in the featured area. If you leave this blank the post title will be used instead.</span>
	</p>
	
	<p>
		<label for="meta-textarea-excerpt" class="prfx-row-title"><?php _e( 'Custom Featured Area Excerpt:', 'hawthorn-meta-fields' )?></label>
		<textarea name="meta-textarea-excerpt" id="meta-textarea-excerpt"><?php if ( isset ( $hawthorn_stored_meta['meta-textarea-excerpt'] ) ) echo $hawthorn_stored_meta['meta-textarea-excerpt'][0]; ?></textarea>
		<span class="solopine-description">Enter a custom excerpt for your featured post to be used in the featured area. If you leave this blank the post excerpt will be used instead.</span>
	</p>
	
	
    <?php
}

/**
 * Saves the custom meta input
 */
function hawthorn_meta_save( $post_id ) {
 
    // Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'hawthorn_nonce' ] ) && wp_verify_nonce( $_POST[ 'hawthorn_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';
 
    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
	
	if( isset( $_POST[ 'meta-select' ] ) ) {
		update_post_meta( $post_id, 'meta-select', $_POST[ 'meta-select' ] );
	}
	
	if( isset( $_POST[ 'meta-image' ] ) ) {
		update_post_meta( $post_id, 'meta-image', $_POST[ 'meta-image' ] );
	}
	
	if( isset( $_POST[ 'meta-textarea' ] ) ) {
		update_post_meta( $post_id, 'meta-textarea', $_POST[ 'meta-textarea' ] );
	}
	if( isset( $_POST[ 'meta-textarea-excerpt' ] ) ) {
		update_post_meta( $post_id, 'meta-textarea-excerpt', $_POST[ 'meta-textarea-excerpt' ] );
	}
	
	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox-fullwidth' ] ) ) {
		update_post_meta( $post_id, 'meta-checkbox-fullwidth', 'yes' );
	} else {
		update_post_meta( $post_id, 'meta-checkbox-fullwidth', '' );
	}
	if( isset( $_POST[ 'meta-checkbox-page-content' ] ) ) {
		update_post_meta( $post_id, 'meta-checkbox-page-content', 'yes' );
	} else {
		update_post_meta( $post_id, 'meta-checkbox-page-content', '' );
	}
	if( isset( $_POST[ 'meta-checkbox-blog-slider' ] ) ) {
		update_post_meta( $post_id, 'meta-checkbox-blog-slider', 'yes' );
	} else {
		update_post_meta( $post_id, 'meta-checkbox-blog-slider', '' );
	}
	
    if( isset( $_POST[ 'meta-text-blog-heading' ] ) ) {
        update_post_meta( $post_id, 'meta-text-blog-heading', sanitize_text_field( $_POST[ 'meta-text-blog-heading' ] ) );
    }
	if( isset( $_POST[ 'meta-select-blog-layout' ] ) ) {
		update_post_meta( $post_id, 'meta-select-blog-layout', $_POST[ 'meta-select-blog-layout' ] );
	}
	if( isset( $_POST[ 'meta-number-posts' ] ) ) {
        update_post_meta( $post_id, 'meta-number-posts', sanitize_text_field( $_POST[ 'meta-number-posts' ] ) );
    }
	if( isset( $_POST[ 'meta-blog-category' ] ) ) {
        update_post_meta( $post_id, 'meta-blog-category', sanitize_text_field( $_POST[ 'meta-blog-category' ] ) );
    }
 
}
add_action( 'save_post', 'hawthorn_meta_save' );

/**
 * Adds the meta box stylesheet when appropriate
 */
function hawthorn_admin_styles(){
    global $typenow;
    if( $typenow == 'post' || $typenow == 'page' ) {
        wp_enqueue_style( 'hawthorn_meta_box_styles', plugin_dir_url( __FILE__ ) . 'hawthorn-meta-field-styles.css' );
    }
}
add_action( 'admin_print_styles', 'hawthorn_admin_styles' );

/**
 * Loads the image management Javascript
 */
function hawthorn_image_enqueue() {
    global $typenow;
    if( $typenow == 'post' || $typenow == 'page' ) {
        wp_enqueue_media();
 
        // Registers and enqueues the required Javascript.
        wp_register_script( 'meta-box-image', plugin_dir_url( __FILE__ ) . 'meta-box-image.js', array( 'jquery' ) );
        wp_localize_script( 'meta-box-image', 'meta_image',
            array(
                'title' => __( 'Choose or Upload an Image', 'hawthorn-meta-fields' ),
                'button' => __( 'Use this image', 'hawthorn-meta-fields' ),
            )
        );
        wp_enqueue_script( 'meta-box-image' );
    }
}
add_action( 'admin_enqueue_scripts', 'hawthorn_image_enqueue' );


function hawthorn_index_func( $atts ){
	
	$a = shortcode_atts( array(
        'cat' => '',
		'title' => '',
        'amount' => '3',
		'cols' => '3',
		'display_title' => 'yes',
		'display_cat' => 'no',
		'display_image' => 'yes',
		'cat_link' => 'yes',
		'cat_link_text' => 'View All',
		'offset' => ''
    ), $atts );
	
	$index_cat = $a['cat'];
	$index_title = $a['title'];
	$index_amount = $a['amount'];
	$index_cols = $a['cols'];
	$index_display_title = $a['display_title'];
	$index_display_cat = $a['display_cat'];
	$index_display_image = $a['display_image'];
	$index_cat_link = $a['cat_link'];
	$index_cat_text = $a['cat_link_text'];
	$offset = $a['offset'];
	
	$query = new WP_Query( array( 'category_name' => $index_cat, 'posts_per_page' => $index_amount, 'ignore_sticky_posts' => true, 'offset' => $offset ) );
	
	ob_start(); ?>
		
		<?php
			if($index_cat) : 
				$idObj = get_category_by_slug($index_cat); 
				$id = $idObj->term_id;
				$cat_link = get_category_link( $id );
			endif;
		?>
		
		<div class="index-shortcode">
		
		<?php if($index_title) : ?>
		<h4 class="index-heading"><span><?php echo esc_html($index_title); ?></span>
		<?php if($index_cat_link == "yes" && $cat_link) : ?>
		<a href="<?php echo esc_url($cat_link); ?>"><?php echo esc_html($index_cat_text); ?> <i class="fa fa-angle-double-right"></i></a>
		<?php endif; ?>
		</h4>
		<?php endif; ?>
		
		<?php if ( $query->have_posts() ) : ?>
		
		<div class="sp-row post-layout">
		
		<?php
			if($index_cols == '3') :
				$cols = 4;
			elseif($index_cols == '4') :
				$cols = 3;
			else :
				$cols = 4;
			endif;
		?>
		
		
		<?php while ( $query->have_posts() ) : $query->the_post(); ?>
			
			<div class="sp-col-<?php echo $cols; ?> index-item">
			<article class="short-grid">
				
				<?php if($index_display_image != 'no') : ?>
				<div class="short-img">
					<?php if(has_post_thumbnail()) : ?>
					<a href="<?php echo get_permalink() ?>"><?php the_post_thumbnail('hawthorn-misc-thumb'); ?></a>
					<?php else : ?>
					<a href="<?php echo get_permalink() ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/default-misc.png" alt="Default" /></a>
					<?php endif; ?>
				</div>
				<?php endif; ?>
				
				<div class="short-header">
					
					<?php if($index_display_cat == 'yes') : ?>
					<span class="cat"><?php the_category('<span>&#8226;</span> '); ?></span>
					<?php endif; ?>
					
					<?php if($index_display_title != 'no') : ?>
					<h2><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>
					<?php endif; ?>
					
				</div>
				
			</article>
			</div>
			
		
		<?php endwhile; ?>
		
		</div>
		
		<?php wp_reset_postdata(); ?>
		
		<?php endif; ?>
		
		</div>
	
	<?php
	return ob_get_clean();
	
}
add_shortcode( 'hawthorn_index', 'hawthorn_index_func' );


add_action( 'admin_head-post.php', 'metabox_switcher' );
add_action( 'admin_head-post-new.php', 'metabox_switcher' );

function metabox_switcher(  ){
	
	global $post;
	
    #Isolate to your specific post type
    if( $post->post_type === 'page' ){

        #Locate the ID of your metabox with Developer tools
        $metabox_selector_id = 'sp-blog-options';

        echo '
            <style type="text/css">
                /* Hide your metabox so there is no latency flash of your metabox before being hidden */
                #'.$metabox_selector_id.'{display:none;}
            </style>
            <script type="text/javascript">
                jQuery(document).ready(function($){

                    //You can find this in the value of the Page Template dropdown
                    var templateName = \'page-blog.php\';

                    //Page template in the publishing options
                    var currentTemplate = $(\'#page_template\');

                    //Identify your metabox
                    var metabox = $(\'#'.$metabox_selector_id.'\');

                    //On DOM ready, check if your page template is selected
                    if(currentTemplate.val() === templateName){
                        metabox.show();
                    }

                    //Bind a change event to make sure we show or hide the metabox based on user selection of a template
                    currentTemplate.change(function(e){
                        if(currentTemplate.val() === templateName){
                            metabox.show();
                        }
                        else{
                            //You should clear out all metabox values here;
                            metabox.hide();
                        }
                    });
                });
            </script>
        ';
    }
}

/* Social share icons */
function hawthorn_share_func(){
	
	ob_start(); ?>
		
		<?php if(!get_theme_mod('hawthorn_post_share')) : ?>
		<div class="<?php if(get_theme_mod('hawthorn_post_share_author') && !get_theme_mod('hawthorn_post_comment_link')) : ?>sp-col-6 left<?php elseif(!get_theme_mod('hawthorn_post_share_author') && get_theme_mod('hawthorn_post_comment_link')) : ?>sp-col-6 right<?php elseif(get_theme_mod('hawthorn_post_share_author') && get_theme_mod('hawthorn_post_comment_link')) : ?>sp-col-12<?php else : ?>sp-col-4<?php endif; ?> col-meta-share">
			<div class="meta-share">
				<?php if(!get_theme_mod('hawthorn_post_share_facebook')) : ?><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa fa-facebook"></i></a><?php endif; ?>
				<?php if(!get_theme_mod('hawthorn_post_share_twitter')) : ?><a target="_blank" href="https://twitter.com/intent/tweet?text=Check%20out%20this%20article:%20<?php print hawthorn_social_title( get_the_title() ); ?>&url=<?php echo urlencode(the_permalink()); ?><?php if(get_theme_mod('hawthorn_twitter')) : ?>&via=<?php echo esc_html(get_theme_mod('hawthorn_twitter')); ?><?php endif; ?>"><i class="fa fa-twitter"></i></a><?php endif; ?>
				<?php $pin_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID)); ?>
				<?php if(!get_theme_mod('hawthorn_post_share_pinterest')) : ?><a data-pin-do="none" target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php echo urlencode(the_permalink()); ?>&media=<?php echo esc_url($pin_image); ?>&description=<?php print hawthorn_social_title( get_the_title() ); ?>"><i class="fa fa-pinterest"></i></a><?php endif; ?>
				<?php if(!get_theme_mod('hawthorn_post_share_google')) : ?><a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class="fa fa-google-plus"></i></a><?php endif; ?>					
			</div>
		</div>
		<?php endif; ?>
	
	<?php
	return ob_get_clean();
	
}
add_shortcode( 'hawthorn_share', 'hawthorn_share_func' );