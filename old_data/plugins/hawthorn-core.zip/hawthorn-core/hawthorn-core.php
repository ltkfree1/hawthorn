<?php
/*
Plugin Name: Hawthorn Core
Plugin URI: http://solopine.com
Description: Hawthorn Core Plugin
Author: Solo Pine
Version: 1.0
Author URI: http://solopine.com
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function hawthorn_core_init() {
	// load language files
	load_plugin_textdomain( 'hawthorn-core', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );

}
add_action( 'init', 'hawthorn_core_init' );


add_action( 'plugins_loaded', 'my_plugin_override' );
function my_plugin_override() {
    include( plugin_dir_path( __FILE__ ) . 'inc/widgets/about_widget.php');
	include( plugin_dir_path( __FILE__ ) . 'inc/widgets/facebook_widget.php');
	include( plugin_dir_path( __FILE__ ) . 'inc/widgets/post_widget.php');
	include( plugin_dir_path( __FILE__ ) . 'inc/widgets/promo_widget.php');
	include( plugin_dir_path( __FILE__ ) . 'inc/widgets/social_widget.php');
}

// Social Share
include( plugin_dir_path( __FILE__ ) . 'inc/social_share.php');

// Social Follow
include( plugin_dir_path( __FILE__ ) . 'inc/social_follow.php');

// TGM
//include( dirname(__FILE__) . '/sitka-core-tgm.php');

// Customizer
//include( dirname(__FILE__) . '/admin/sitka_core_customizer_setup.php');

// Social Share
//include( dirname(__FILE__) . '/social/social-share.php');

// Social Icons
//include( dirname(__FILE__) . '/social/social-icons.php');

// Author Social Icons
//include( dirname(__FILE__) . '/social/author-social-icons.php');

// Widgets


//include( dirname(__FILE__) . '/inc/widgets/social_widget.php');

//include( dirname(__FILE__) . '/inc/widgets/promo_widget.php');



//include( dirname(__FILE__) . '/inc/widgets/post_widget.php');

//include( dirname(__FILE__) . '/inc/widgets/facebook_widget.php');
