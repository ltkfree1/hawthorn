<?php
/*
* Social Media Customizer Settings
*/
function hawthorn_core_register_social_follow( $wp_customize ) {
 	
	include( plugin_dir_path( __FILE__ ) . 'social_follow_settings.php');
 
}
add_action( 'customize_register', 'hawthorn_core_register_social_follow' );

/*
* Checkbox sanitize
*/
function hawthorn_core_sanitize_checkbox( $input ) {
    if ( $input == 1 ) {
        return 1;
    } else {
        return '';
    }
}

/*
* Get Social Follow Icons
*/
function hawthorn_core_get_social_icons() { ?>
	<?php if(get_theme_mod('hawthorn_facebook')) : ?><?php if(get_theme_mod('hawthorn_facebook_header')) : ?><a href="https://facebook.com/<?php echo esc_html(get_theme_mod('hawthorn_facebook')); ?>" target="_blank"><i class="fa fa-facebook-square"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_twitter')) : ?><?php if(get_theme_mod('hawthorn_twitter_header')) : ?><a href="https://twitter.com/<?php echo esc_html(get_theme_mod('hawthorn_twitter')); ?>" target="_blank"><i class="fa fa-twitter"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_instagram')) : ?><?php if(get_theme_mod('hawthorn_instagram_header')) : ?><a href="https://instagram.com/<?php echo esc_html(get_theme_mod('hawthorn_instagram')); ?>" target="_blank"><i class="fa fa-instagram"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_pinterest')) : ?><?php if(get_theme_mod('hawthorn_pinterest_header')) : ?><a href="https://pinterest.com/<?php echo esc_html(get_theme_mod('hawthorn_pinterest')); ?>" target="_blank"><i class="fa fa-pinterest"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_bloglovin')) : ?><?php if(get_theme_mod('hawthorn_bloglovin_header')) : ?><a href="https://bloglovin.com/<?php echo esc_html(get_theme_mod('hawthorn_bloglovin')); ?>" target="_blank"><i class="fa fa-heart"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_tumblr')) : ?><?php if(get_theme_mod('hawthorn_tumblr_header')) : ?><a href="https://<?php echo esc_html(get_theme_mod('hawthorn_tumblr')); ?>.tumblr.com/" target="_blank"><i class="fa fa-tumblr"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_youtube')) : ?><?php if(get_theme_mod('hawthorn_youtube_header')) : ?><a href="https://youtube.com/<?php echo esc_html(get_theme_mod('hawthorn_youtube')); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_dribbble')) : ?><?php if(get_theme_mod('hawthorn_dribbble_header')) : ?><a href="https://dribbble.com/<?php echo esc_html(get_theme_mod('hawthorn_dribbble')); ?>" target="_blank"><i class="fa fa-dribbble"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_soundcloud')) : ?><?php if(get_theme_mod('hawthorn_soundcloud_header')) : ?><a href="https://soundcloud.com/<?php echo esc_html(get_theme_mod('hawthorn_soundcloud')); ?>" target="_blank"><i class="fa fa-soundcloud"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_vimeo')) : ?><?php if(get_theme_mod('hawthorn_vimeo_header')) : ?><a href="https://vimeo.com/<?php echo esc_html(get_theme_mod('hawthorn_vimeo')); ?>" target="_blank"><i class="fa fa-vimeo-square"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_linkedin')) : ?><?php if(get_theme_mod('hawthorn_linkedin_header')) : ?><a href="<?php echo esc_html(get_theme_mod('hawthorn_linkedin')); ?>" target="_blank"><i class="fa fa-linkedin"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_snapchat')) : ?><?php if(get_theme_mod('hawthorn_snapchat_header')) : ?><a href="https://snapchat.com/add/<?php echo esc_html(get_theme_mod('hawthorn_snapchat')); ?>" target="_blank"><i class="fa fa-snapchat-ghost"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_email')) : ?><?php if(get_theme_mod('hawthorn_email_header')) : ?><a href="mailto:<?php echo esc_url(get_theme_mod('hawthorn_email')); ?>" target="_blank"><i class="fa fa-envelope-o"></i></a><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_rss')) : ?><?php if(get_theme_mod('hawthorn_rss_header')) : ?><a href="<?php echo esc_url(get_theme_mod('hawthorn_rss')); ?>" target="_blank"><i class="fa fa-rss"></i></a><?php endif; ?><?php endif; ?>
<?php }

/*
* Get Social Follow Icons (Footer)
*/
function hawthorn_core_get_social_icons_footer() { ?>
	<?php if(get_theme_mod('hawthorn_facebook')) : ?><?php if(get_theme_mod('hawthorn_facebook_footer')) : ?><li><a href="http://facebook.com/<?php echo esc_html(get_theme_mod('hawthorn_facebook')); ?>" target="_blank"><i class="fa fa-facebook-square"></i><span><?php esc_html_e( 'Facebook', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_twitter')) : ?><?php if(get_theme_mod('hawthorn_twitter_footer')) : ?><li><a href="http://twitter.com/<?php echo esc_html(get_theme_mod('hawthorn_twitter')); ?>" target="_blank"><i class="fa fa-twitter"></i><span><?php esc_html_e( 'Twitter', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_instagram')) : ?><?php if(get_theme_mod('hawthorn_instagram_footer')) : ?><li><a href="http://instagram.com/<?php echo esc_html(get_theme_mod('hawthorn_instagram')); ?>" target="_blank"><i class="fa fa-instagram"></i><span><?php esc_html_e( 'Instagram', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_pinterest')) : ?><?php if(get_theme_mod('hawthorn_pinterest_footer')) : ?><li><a href="http://pinterest.com/<?php echo esc_html(get_theme_mod('hawthorn_pinterest')); ?>" target="_blank"><i class="fa fa-pinterest"></i><span><?php esc_html_e( 'Pinterest', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_bloglovin')) : ?><?php if(get_theme_mod('hawthorn_bloglovin_footer')) : ?><li><a href="http://bloglovin.com/<?php echo esc_html(get_theme_mod('hawthorn_bloglovin')); ?>" target="_blank"><i class="fa fa-heart"></i><span><?php esc_html_e( 'Bloglovin', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_tumblr')) : ?><?php if(get_theme_mod('hawthorn_tumblr_footer')) : ?><li><a href="http://<?php echo esc_html(get_theme_mod('hawthorn_tumblr')); ?>.tumblr.com/" target="_blank"><i class="fa fa-tumblr"></i><span><?php esc_html_e( 'Tumblr', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_youtube')) : ?><?php if(get_theme_mod('hawthorn_youtube_footer')) : ?><li><a href="http://youtube.com/<?php echo esc_html(get_theme_mod('hawthorn_youtube')); ?>" target="_blank"><i class="fa fa-youtube-play"></i><span><?php esc_html_e( 'Youtube', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_dribbble')) : ?><?php if(get_theme_mod('hawthorn_dribbble_footer')) : ?><li><a href="http://dribbble.com/<?php echo esc_html(get_theme_mod('hawthorn_dribbble')); ?>" target="_blank"><i class="fa fa-dribbble"></i><span><?php esc_html_e( 'Dribbble', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_soundcloud')) : ?><?php if(get_theme_mod('hawthorn_soundcloud_footer')) : ?><li><a href="http://soundcloud.com/<?php echo esc_html(get_theme_mod('hawthorn_soundcloud')); ?>" target="_blank"><i class="fa fa-soundcloud"></i><span><?php esc_html_e( 'Soundcloud', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_vimeo')) : ?><?php if(get_theme_mod('hawthorn_vimeo_footer')) : ?><li><a href="http://vimeo.com/<?php echo esc_html(get_theme_mod('hawthorn_vimeo')); ?>" target="_blank"><i class="fa fa-vimeo-square"></i><span><?php esc_html_e( 'Vimeo', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_linkedin')) : ?><?php if(get_theme_mod('hawthorn_linkedin_footer')) : ?><li><a href="<?php echo esc_html(get_theme_mod('hawthorn_linkedin')); ?>" target="_blank"><i class="fa fa-linkedin"></i><span><?php esc_html_e( 'LinkedIn', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_snapchat')) : ?><?php if(get_theme_mod('hawthorn_snapchat_footer')) : ?><li><a href="http://snapchat.com/add/<?php echo esc_html(get_theme_mod('hawthorn_snapchat')); ?>" target="_blank"><i class="fa fa-snapchat-ghost"></i><span><?php esc_html_e( 'Snapchat', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_email')) : ?><?php if(get_theme_mod('hawthorn_email_footer')) : ?><li><a href="mailto:<?php echo esc_url(get_theme_mod('hawthorn_email')); ?>" target="_blank"><i class="fa fa-rss"></i><span><?php esc_html_e( 'E-mail', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
	<?php if(get_theme_mod('hawthorn_rss')) : ?><?php if(get_theme_mod('hawthorn_rss_footer')) : ?><li><a href="<?php echo esc_url(get_theme_mod('hawthorn_rss')); ?>" target="_blank"><i class="fa fa-rss"></i><span><?php esc_html_e( 'RSS', 'hawthorn-core' ); ?></span></a></li><?php endif; ?><?php endif; ?>
<?php }