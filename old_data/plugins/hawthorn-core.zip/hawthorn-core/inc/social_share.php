<?php
/*
* Twitter ampersand entity decode
*/
function hawthorn_core_social_title( $title ) {
    $title = html_entity_decode( $title );
    $title = urlencode( $title );
    return $title;
}

/*
* Get share buttons
*/
function hawthorn_core_get_social_share() {
	
	// Get Featured image for pinterest
	$pin_image = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID())); ?>
	
	<?php if(!get_theme_mod('hawthorn_post_share_facebook', false)) : ?><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa fa-facebook"></i></a><?php endif; ?>
	<?php if(!get_theme_mod('hawthorn_post_share_twitter', false)) : ?><a target="_blank" href="https://twitter.com/intent/tweet?text=Check%20out%20this%20article:%20<?php print hawthorn_core_social_title( get_the_title() ); ?>&url=<?php echo urlencode(the_permalink()); ?><?php if(get_theme_mod('hawthorn_twitter')) : ?>&via=<?php echo esc_html(get_theme_mod('hawthorn_twitter')); ?><?php endif; ?>"><i class="fa fa-twitter"></i></a><?php endif; ?>
	<?php if(!get_theme_mod('hawthorn_post_share_pinterest', false)) : ?><a data-pin-do="none" target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php echo urlencode(the_permalink()); ?>&media=<?php echo esc_url($pin_image); ?>&description=<?php print hawthorn_core_social_title( get_the_title() ); ?>"><i class="fa fa-pinterest"></i></a><?php endif; ?>
	<?php if(!get_theme_mod('hawthorn_post_share_linkedin', false)) : ?><a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(the_permalink()); ?>&title=<?php print hawthorn_core_social_title( get_the_title() ); ?>&summary=&source="><i class="fa fa-linkedin"></i></a><?php endif; ?>
	
<?php }